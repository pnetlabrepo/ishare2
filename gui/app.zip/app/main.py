from fastapi import FastAPI, Request

from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

import uvicorn
import requests
import json

from ishare2_search_bin import get_bin_list
from ishare2_search_dynamips import get_dynamips_list
from ishare2_search_qemu import get_qemu_list

from ishare2_pull_bin import download_bin_image
from ishare2_pull_dynamips import download_dynamips_image
from ishare2_pull_qemu import download_qemu_image

from ishare2_installed_bin import get_installed_bin_images
from ishare2_installed_dynamips import get_installed_dynamips_images
from ishare2_installed_qemu import get_installed_qemu_images

from delete_images import delete_bin_image
from delete_images import delete_dynamips_image
from delete_images import delete_qemu_image

app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="templates")

def get_credentials():
    with open('config.json', 'r') as f:
        return json.load(f)

@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    config = get_credentials()
    URL_ISHARE2_VERSION = config["constants"]["ishare2_version"]

    ishare2_version = requests.get(URL_ISHARE2_VERSION).text

    data = {
        "version": ishare2_version,
        "extras1": "Field #1 to add more info",
        "extras2": "Field #2 to add more info",
        "extras3": "Field #3 to add more info"
    }
    #return data
    return templates.TemplateResponse("home.html", {"request": request, "data": data})

@app.get("/lists/bin")
async def root(request: Request):
    data = get_bin_list()
    #return data
    return templates.TemplateResponse("bin_list.html", {"request": request, "data": data})

@app.get("/lists/dynamips")
async def root(request: Request):
    data = get_dynamips_list()
    #return data
    return templates.TemplateResponse("dynamips_list.html", {"request": request, "data": data})

@app.get("/lists/qemu")
async def root(request: Request):
    data = get_qemu_list()
    #return data
    return templates.TemplateResponse("qemu_list.html", {"request": request, "data": data})
    
@app.get("/download/bin/{id}")
async def download_bin(id):
    return download_bin_image(id)

@app.get("/delete/bin/{name}")
async def delete_bin(name):
    return delete_bin_image(name)

@app.get("/download/dynamips/{id}")
async def download_dynamips(id):
    return download_dynamips_image(id)

@app.get("/delete/dynamips/{name}")
async def delete_dynamips(name):
    return delete_dynamips_image(name)

@app.get("/download/qemu/{id}")
async def download_qemu(id):
    return download_qemu_image(id) 

@app.get("/delete/qemu/{foldername}")
async def delete_qemu(foldername):
    return delete_qemu_image(foldername)

@app.get("/installed/bin")
async def get_installed_bin(request: Request):
    data = get_installed_bin_images()
    #return data
    return templates.TemplateResponse("installed_bin_images.html", {"request": request, "data": data})

@app.get("/installed/dynamips")
async def get_installed_dynamips(request: Request):
    data = get_installed_dynamips_images()
    #return data
    return templates.TemplateResponse("installed_dynamips_images.html", {"request": request, "data": data})

@app.get("/installed/qemu")
async def get_installed_qemu(request: Request):
    data = get_installed_qemu_images()
    #return data
    return templates.TemplateResponse("installed_qemu_images.html", {"request": request, "data": data})

if __name__ == "__main__":
    config = get_credentials()
    HOST = config["api"]["host"]
    PORT = config["api"]["port"]

    uvicorn.run(
        "main:app",
        host=HOST,
        port=PORT,
        reload=True,
        workers=4,
    )
