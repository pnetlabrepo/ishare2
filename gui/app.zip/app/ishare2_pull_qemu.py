import subprocess


def download_qemu_image(id):
    command = f'ishare2 pull qemu {id}'
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for line in p.stdout:
        output = line.decode()
        print(output)
    
    if "Fix permissions command has been applied" in output:
        return {"message": f"Image with id: {id} has been downloaded successfully"} 

    if "already exists in server" in output:
        return {"message": f"Image with id: {id} already exists in server"}