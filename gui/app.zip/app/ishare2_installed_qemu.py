import subprocess
from ishare2_search_qemu import get_qemu_list

def get_installed_qemu_images():
    command = "ls -l /opt/unetlab/addons/qemu/ | awk '{ print $9 }'"
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    data = []
    for line in p.stdout:
        output = line.decode()
        data.append(output)
    
    data = data[1:]

    my_list = []
    for sub in data:
        my_list.append(sub.replace("\n", ""))

    qemu_list = get_qemu_list()

    final_list = []
    for qemu in qemu_list:
        for value in my_list:
            if value == qemu["foldername"]:
                dictionary = {
                    "id": qemu["id"],
                    "name": qemu["foldername"],
                    "size": qemu["size"],
                    "unit": qemu["unit"]
                }
                final_list.append(dictionary)
    return final_list
    
    # dictionary = {}
    # final_list = []
    # for element in my_list:
    #     dictionary = {
    #         "name": element, 
    #     }
    #     final_list.append(dictionary)
    # return final_list