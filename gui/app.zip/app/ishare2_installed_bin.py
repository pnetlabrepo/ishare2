import subprocess
from ishare2_search_bin import get_bin_list

def get_installed_bin_images():
    command = "ls -l /opt/unetlab/addons/iol/bin/ | awk '{ print $9 }'"
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    data = []
    for line in p.stdout:
        output = line.decode()
        if "CiscoIOUKeygen.py" in output:
            continue

        if "iourc" in output:
            continue

        if "keepalive.pl" in output:
            continue   
        data.append(output)
    data = data[1:]

    my_list = []
    for sub in data:
        my_list.append(sub.replace("\n", ""))

    bin_list = get_bin_list()

    final_list = []
    for bin in bin_list:
        for value in my_list:
            if value == bin["name"]:
                dictionary = {
                    "id": bin["id"],
                    "name": bin["name"],
                    "size": bin["size"],
                    "unit": bin["unit"]
                }
                final_list.append(dictionary)
    return final_list
    
    # dictionary = {}
    # final_list = []
    # for element in my_list:
    #     dictionary = {
    #         "name": element, 
    #     }
    #     final_list.append(dictionary)
    # return final_list



