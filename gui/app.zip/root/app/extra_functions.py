import subprocess


def relicense():
    command = "ishare2 relicense"
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    data = []
    for line in p.stdout:
        output = line.decode()

    if "Done" in output:
        command = "cat /opt/unetlab/addons/iol/bin/iourc"
        p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        data = []
        for line in p.stdout:
            output2 = line.decode()
        license_value = output2[10:-2]
        
        return {
            "status": 1,
            "message": "Relicense command has been applied successfully",
            "license_value": license_value
        }
    else:
        return {
            "status": 0,
            "message": "Something went wrong",
        } 