<?php

namespace App\Helpers\Encrypt;

class Encrypt
{

    public static $log = '';
    

    
}
