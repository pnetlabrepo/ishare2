<?php
define('UPLOADER_DISKS_TABLE', 'uploader_disks');
define('DISK_ID', 'disk_id');
define('DISK_NAME', 'disk_name');
define('DISK_TYPE', 'disk_type');
define('DISK_CONFIG', 'disk_config');
define('DISK_WEIGHT', 'disk_weight');
define('DISK_TOTAL', 'disk_total');
define('DISK_USED', 'disk_used');
define('DISK_FREE', 'disk_free');
define('DISK_ACTIVE', 'disk_active');
define('DISK_TARGET', 'disk_target');
define('DISK_UPLOADER', 'disk_uploader');