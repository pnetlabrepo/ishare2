<?php
define('PACKAGES_TABLE', 'packages');
define('PACK_ID', 'pack_id');
define('PACK_PATH', 'pack_path');
define('PACK_MD5', 'pack_md5');
define('PACK_SIZE', 'pack_size');