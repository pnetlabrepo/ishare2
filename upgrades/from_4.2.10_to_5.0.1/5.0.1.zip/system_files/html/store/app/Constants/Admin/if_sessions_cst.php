<?php
define('IF_SESSIONS_TABLE', 'if_sessions');
define('IF_SESSION_ID', 'if_session_id');
define('IF_SESSION_LAB', 'if_session_lab');
define('IF_SESSION_NODE', 'if_session_node');
define('IF_SESSION_IFID', 'if_session_ifid');
define('IF_SESSION_TYPE', 'if_session_type');
define('IF_SESSION_QUALITY', 'if_session_quality');
define('IF_SESSION_SUSPEND', 'if_session_suspend');
