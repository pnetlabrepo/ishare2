<?php
define('NODE_SESSIONS_TABLE', 'node_sessions');
define('NODE_SESSION_ID', 'node_session_id');
define('NODE_SESSION_NID', 'node_session_nid');
define('NODE_SESSION_LAB', 'node_session_lab');
define('NODE_SESSION_PORT', 'node_session_port');
define('NODE_SESSION_TYPE', 'node_session_type');
define('NODE_SESSION_WORKSPACE', 'node_session_workspace');
define('NODE_SESSION_RAM', 'node_session_ram');
define('NODE_SESSION_CPU', 'node_session_cpu');
define('NODE_SESSION_HDD', 'node_session_hdd');
define('NODE_SESSION_RUNNING', 'node_session_running');
define('NODE_SESSION_POD', 'node_session_pod');
define('NODE_SESSION_IOL', 'node_session_iol');
