<?php 
#from pnetlab

define('APP_DOMAIN', 'user.pnetlab.com');
define('APP_AUTHEN', 'https://authen.pnetlab.com');
define('APP_UPLOAD', 'https://uploader.pnetlab.com');
define('APP_ADMIN', 'https://admin.pnetlab.com');
define('APP_CENTER', 'https://user.pnetlab.com');

?>