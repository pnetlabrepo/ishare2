<?php
define('USERS_TABLE', 'users');
define('USER_USERNAME', 'username');
define('USER_COOKIE', 'cookie');
define('USER_EMAIL', 'email');
define('USER_EXPIRATION', 'expiration');
define('USER_NAME', 'name');
define('USER_PASSWORD', 'password');
define('USER_SESSION', 'session');
define('USER_IP', 'ip');
define('USER_ROLE', 'role');
define('USER_FOLDER', 'folder');
define('USER_HTML5', 'html5');
define('USER_LICENSE', 'license');
define('USER_ONLINE_TIME', 'online_time');
define('USER_LAB_SESSION', 'lab_session');
define('USER_POD', 'pod');
define('USER_NOTE', 'note');
define('USER_OFFLINE', 'offline');
define('USER_ACTIVE_TIME', 'active_time');
define('USER_EXPIRED_TIME', 'expired_time');
define('USER_STATUS', 'user_status');
define('USER_WORKSPACE', 'user_workspace');
define('USER_MAX_NODE', 'max_node');
define('USER_MAX_NODELAB', 'max_node_lab');

define('USER_STATUS_ACTIVE', '1');
define('USER_STATUS_BLOCK', '0');