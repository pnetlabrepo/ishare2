<?php
define('LAB_SESSIONS_TABLE', 'lab_sessions');
define('LAB_SESSION_ID', 'lab_session_id');
define('LAB_SESSION_LID', 'lab_session_lid');
define('LAB_SESSION_POD', 'lab_session_pod');
define('LAB_SESSION_JOINED', 'lab_session_joined');
define('LAB_SESSION_PATH', 'lab_session_path');
define('LAB_SESSION_RUNNING', 'lab_session_running');