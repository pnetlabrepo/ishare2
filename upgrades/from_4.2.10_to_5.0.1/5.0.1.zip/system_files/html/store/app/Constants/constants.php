<?php 
define('APP_NAME', 'PNETLab');
define('APP_SLOGAN', 'Lab is Simple');
define('APP_TITLE', 'PNETLab | Lab is Simple');
define('APP_SECURE', 'http://secure.pnet-lab.com');

?>