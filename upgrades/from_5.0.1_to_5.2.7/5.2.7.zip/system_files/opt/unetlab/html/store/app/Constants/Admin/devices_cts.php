<?php
define('DEVICES_TABLE', 'devices');
define('DEVICE_ID', 'device_id');
define('DEVICE_NAME', 'device_name');
define('DEVICE_IMG', 'device_img');
define('DEVICE_DES', 'device_des');
define('DEVICE_SCRIPT', 'device_script');
define('DEVICE_CHECK', 'device_check');
define('DEVICE_WEIGHT', 'device_weight');
define('DEVICE_PUBLIC', 'device_public');
define('DEVICE_COUNT', 'device_count');
define('DEVICE_TARGET', 'device_target');
define('DEVICE_DELETE', 'device_delete');