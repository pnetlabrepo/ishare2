<?php
define('DEPENDENCE_TABLE', 'dependence');
define('DEPEND_ID', 'depend_id');
define('DEPEND_VID', 'depend_vid');
define('DEPEND_PATH', 'depend_path');
define('DEPEND_MD5', 'depend_md5');