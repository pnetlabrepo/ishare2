<?php
define('USER_ROLES_TABLE', 'user_roles');
define('USER_ROLE_ID', 'user_role_id');
define('USER_ROLE_NAME', 'user_role_name');
define('USER_ROLE_WORKSPACE', 'user_role_workspace');
define('USER_ROLE_NOTE', 'user_role_note');
define('USER_ROLE_RAM', 'user_role_ram');
define('USER_ROLE_CPU', 'user_role_cpu');
define('USER_ROLE_HDD', 'user_role_hdd');

define('LOCAL_PASS', 'pnet');