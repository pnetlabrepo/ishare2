<?php
define('UPLOADER_FILES_TABLE', 'uploader_files');
define('FILE_ID', 'file_id');
define('FILE_UPLOADER', 'file_uploader');
define('FILE_DISK', 'file_disk');
define('FILE_TABLE', 'file_table');
define('FILE_COLUMN', 'file_column');
define('FILE_UID', 'file_uid');
define('FILE_PATH', 'file_path');
define('FILE_SIZE', 'file_size');
define('FILE_NAME', 'file_name');