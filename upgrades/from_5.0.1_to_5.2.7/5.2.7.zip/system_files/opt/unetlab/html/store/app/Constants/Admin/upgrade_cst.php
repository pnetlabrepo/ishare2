<?php
define('UPGRADE_TABLE', 'upgrade');
define('UPGRADE_ID', 'upgrade_id');
define('UPGRADE_VERSION', 'upgrade_version');
define('UPGRADE_STATUS', 'upgrade_status');
define('UPGRADE_INDEX', 'upgrade_index');
define('UPGRADE_NOTE', 'upgrade_note');
define('UPGRADE_FILE', 'upgrade_file');
define('UPGRADE_TARGET', 'upgrade_target');