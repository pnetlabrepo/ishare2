<?php
define('MULTI_ACCESS_TABLE', 'multi_access');
define('MULTI_ACCESS_ID', 'multi_access_id');
define('MULTI_ACCESS_UID', 'multi_access_uid');
define('MULTI_ACCESS_BOX', 'multi_access_box');
define('MULTI_ACCESS_EMAIL', 'multi_access_email');
define('MULTI_ACCESS_NOTE', 'multi_access_note');
define('MULTI_ACCESS_TIME', 'multi_access_time');