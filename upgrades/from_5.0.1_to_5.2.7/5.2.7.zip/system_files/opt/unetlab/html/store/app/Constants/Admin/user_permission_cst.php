<?php
define('USER_PERMISSION_TABLE', 'user_permission');
define('USER_PER_ID', 'user_per_id');
define('USER_PER_ROLE', 'user_per_role');
define('USER_PER_NAME', 'user_per_name');

define('USER_PER_DEL_FOLDER', 'DELETE_FOLDER');
define('USER_PER_ADD_FOLDER', 'ADD_FOLDER');
define('USER_PER_EDIT_FOLDER', 'EDIT_FOLDER');
define('USER_PER_DEL_LAB', 'DELETE_LAB');
define('USER_PER_ADD_LAB', 'ADD_LAB');
define('USER_PER_IMPORT_LAB', 'IMPORT_LAB');
define('USER_PER_EXPORT_LAB', 'EXPORT_LAB');
define('USER_PER_MOVE_LAB', 'MOVE_LAB');
define('USER_PER_CLONE_LAB', 'CLONE_LAB');
define('USER_PER_RENAME_LAB', 'RENAME_LAB');

define('USER_PER_EDIT_LAB', 'EDIT_LAB');
define('USER_PER_JOIN_LAB', 'JOIN_LAB');
define('USER_PER_OPEN_LAB', 'OPEN_LAB');