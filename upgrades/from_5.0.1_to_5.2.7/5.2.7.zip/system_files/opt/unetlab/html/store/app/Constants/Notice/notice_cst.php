<?php
define('NOTICE_TABLE', 'notice');
define('NOTICE_ID', 'notice_id');
define('NOTICE_TIME', 'notice_time');
define('NOTICE_UID', 'notice_uid');
define('NOTICE_UNAME', 'notice_uname');
define('NOTICE_FIRE_UID', 'notice_fire_uid');
define('NOTICE_FIRE_UNAME', 'notice_fire_uname');
define('NOTICE_CONTENT', 'notice_content');
define('NOTICE_VARIABLE', 'notice_variable');
define('NOTICE_SEEN', 'notice_seen');
define('NOTICE_LEVEL', 'notice_level');
define('NOTICE_ACTION', 'notice_action');