<?php
define('NOTICE_WEB_TABLE', 'notice_web');
define('WEB_NOTICE_ID', 'web_notice_id');
define('WEB_NOTICE_SUBSCRIPTION', 'web_notice_subscription');
define('WEB_NOTICE_SUBMD5', 'web_notice_submd5');
define('WEB_NOTICE_UID', 'web_notice_uid');
define('WEB_NOTICE_UNAME', 'web_notice_uname');
define('WEB_NOTICE_RESULT', 'web_notice_result');
define('WEB_NOTICE_TIME', 'web_notice_time');