<?php
define('PROCESS_TABLE', 'process');
define('PROCESS_ID', 'process_id');
define('PROCESS_DTOTAL', 'process_dtotal');
define('PROCESS_DNOW', 'process_dnow');
define('PROCESS_UTOTAL', 'process_utotal');
define('PROCESS_UNOW', 'process_unow');
define('PROCESS_FINISH', 'process_finish');