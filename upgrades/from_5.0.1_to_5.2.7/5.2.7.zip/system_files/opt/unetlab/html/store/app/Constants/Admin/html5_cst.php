<?php
define('HTML5_TABLE', 'html5');
define('HTML5_USERNAME', 'username');
define('HTML5_POD', 'pod');
define('HTML5_TOKEN', 'token');