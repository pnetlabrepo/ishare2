<?php
define('PROCESS_DEVICE_TABLE', 'process_device');
define('PROCESS_DEVICE_ID', 'process_device_id');
define('PROCESS_DEVICE_DTOTAL', 'process_device_dtotal');
define('PROCESS_DEVICE_DNOW', 'process_device_dnow');
define('PROCESS_DEVICE_UTOTAL', 'process_device_utotal');
define('PROCESS_DEVICE_UNOW', 'process_device_unow');
define('PROCESS_DEVICE_LOG', 'process_device_log');